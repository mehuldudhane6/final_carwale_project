import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dhawal',
  templateUrl: './dhawal.component.html',
  styleUrls: ['./dhawal.component.css']
})
export class DhawalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
