import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { UserService } from '../user.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isAdmin: boolean = false;
  public isAdminObs: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient,
    private userService: UserService) { }

  ngOnInit(): void {

  }

  public uiInvalidCredential = false;

  fbGroup = this.fb.group({
    username: ['', [Validators.required, Validators.minLength(3)]],
    password: ['', [Validators.required, Validators.maxLength(20)]],

  });

  async loginprocess() {
    const data = this.fbGroup.value;
    const url = 'http://localhost:3000/auth-user';
    const result: any = await this.http.post(url, data).toPromise();
    console.log(result);
    if (result.opr) {
      this.isAdmin = result.result[0].role === 'user' ? false : true;
      this.userService.setisAdminObs(this.isAdmin);
      sessionStorage.setItem('sid', 'true');
      this.router.navigate(['home']);
    } else {
      this.uiInvalidCredential = true;
      alert("plz...enter valid credentials")
    }


  }

}
