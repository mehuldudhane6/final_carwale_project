import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient) {

  }

  fbGroup = this.fb.group(
    {
      username: ['', [Validators.required, Validators.minLength(3), Validators.pattern('[a-zA-z]*')]],
      password: ['', [Validators.required, Validators.maxLength(8)]],
      email: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      mobile: ['', [Validators.required]],
    }
  )


  ngOnInit(): void {
  }

  async registerHere() {
    const data = this.fbGroup.value;
    const url = "http://localhost:3000/adduser";
    await this.http.post(url, data).toPromise();

    this.router.navigate(['login'])
  }
}
