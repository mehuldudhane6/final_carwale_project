import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-project';
  public list: any = []
  constructor(private http: HttpClient) {

  }
  async handleAjax() {
    const url = "https://reqres.in/api/users?page=2";
    const results = await this.http.get(url).toPromise()
    console.log(results);
    this.list = results;
  }
}
