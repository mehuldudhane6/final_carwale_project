import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
  filteredCars: any;
  cars: any = []

  constructor(private router: Router, private http: HttpClient,) { }
  ngOnInit(): void {
    let validation = sessionStorage.getItem('sid');
    if (!validation) {
      this.router.navigate(['login']);
    }
    this.getCarDetails();
  }
  async getCarDetails() {
    const data = {};
    const url = 'http://localhost:3000/get-car-details';
    const result: any = await this.http.post(url, data).toPromise();
    console.log(result);
    this.cars = result.result
    this.cars[0].path = "assets/images/1.webp";
    this.filteredCars = this.cars;
  }

  filterCars(filterType) {
    const type = filterType;
    console.log(type)
    console.log(this.cars);
    this.filteredCars = this.cars.filter((item) => {
      return item.carType === type
    });
    console.log(this.filteredCars);
  }

}
