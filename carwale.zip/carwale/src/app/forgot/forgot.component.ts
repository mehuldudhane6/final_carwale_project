import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

import { HttpClientModule, HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient) { }

  fbGroup = this.fb.group(
    {
      email: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.maxLength(8)]],
      NewPassword: ['', [Validators.required, Validators.maxLength(8)]],
    }
  )

  ngOnInit(): void {
  }


  async validatingField() {
    const data = this.fbGroup.value;
    console.log(data);
    if (data.password = data.NewPassword) {
      const url = 'http://localhost:3000/forgotPassword';
      const result: any = await this.http.post(url, data).toPromise();
    }
    else {
      alert("plz..confirm your password again");
    }
  }
}
