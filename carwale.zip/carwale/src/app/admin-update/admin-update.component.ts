import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-admin-update',
  templateUrl: './admin-update.component.html',
  styleUrls: ['./admin-update.component.css']
})
export class AdminUpdateComponent implements OnInit {
  selectedCarDetails: any;
  carId: number;

  constructor(private fb: FormBuilder, private router: Router, private http: HttpClient, private route: ActivatedRoute) { }
  fbGroup = this.fb.group(
    {
      carId: [''],
      company: [''],
      price: [''],
      carType: [''],
      mileage: [''],
      engine: [''],
      fuelType: [''],
      seatingCapacity: [''],
      path: [''],
    }
  )

  ngOnInit(): void {
    this.getQueryParameter();
  }

  getQueryParameter() {
    this.route.paramMap.subscribe((params) => {
      this.carId = +params.get('id');
      console.log(this.carId);
      this.getCarDetails();

    })
  }

  async getCarDetails() {
    const url = 'http://localhost:3000/getCarDetailsById';
    const data = { 'id': this.carId };
    const result: any = await this.http.post(url, data).toPromise();
    console.log(result);
    this.selectedCarDetails = result.result[0];
    console.log(this.selectedCarDetails);

    this.updateCarDetailsValue();
  }

  updateCarDetailsValue() {
    this.fbGroup.setValue({
      carId: this.selectedCarDetails.carId,
      company: this.selectedCarDetails.company,
      price: this.selectedCarDetails.price,
      carType: this.selectedCarDetails.carType,
      mileage: this.selectedCarDetails.mileage,
      engine: this.selectedCarDetails.engine,
      fuelType: this.selectedCarDetails.fuelType,
      seatingCapacity: this.selectedCarDetails.seatingCapacity,
      path: this.selectedCarDetails.path,
    });
  }

  async updateData() {
    let data = this.fbGroup.value;
    console.log(data);
    const url = "http://localhost:3000/updateData";
    await this.http.post(url, data).toPromise();
    alert("Updated Successfully");
  }

}
