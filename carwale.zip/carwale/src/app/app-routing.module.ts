import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BodyComponent } from './body/body.component';
import { HeaderComponent } from './header/header.component';
import { CarInfo1Component } from './car-info1/car-info1.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotComponent } from './forgot/forgot.component';
import { FooterComponent } from './footer/footer.component';
import { DhawalComponent } from './dhawal/dhawal.component';
import { AdminUpdateComponent } from './admin-update/admin-update.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'forgot',
    component: ForgotComponent
  },
  {
    path: 'home',
    component: BodyComponent
  },
  {
    path: 'car-info/:id',
    component: CarInfo1Component
  },
  {
    path: 'update/:id',
    component: AdminUpdateComponent
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
