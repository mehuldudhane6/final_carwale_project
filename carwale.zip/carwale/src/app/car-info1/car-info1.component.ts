import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { UserService } from '../user.service';
@Component({
  selector: 'app-car-info1',
  templateUrl: './car-info1.component.html',
  styleUrls: ['./car-info1.component.css']
})
export class CarInfo1Component implements OnInit {
  carId: number;
  isAdmin: boolean = false;
  selectedCarDetails: any;
  constructor(private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private userService: UserService) { }

  ngOnInit(): void {
    this.getisAdmin();
    this.getQueryParameter();
  }
  getisAdmin() {
    this.userService.getisAdminObs().subscribe((data) => {
      this.isAdmin = data;
      console.log(this.isAdmin);
    })
  }

  getQueryParameter() {
    this.route.paramMap.subscribe((params) => {
      this.carId = +params.get('id');
      console.log(this.carId);
      this.getCarDetails();

    })
  }
  async getCarDetails() {
    const url = 'http://localhost:3000/getCarDetailsById';
    const data = { 'id': this.carId };
    const result: any = await this.http.post(url, data).toPromise();
    console.log(result);
    this.selectedCarDetails = result.result[0];


  }

  bookNowProcess() {
    alert("Car Booked Successfully");
  }

  async onDeleteCarDetails() {
    if (confirm("Are ypu sure You wish to Delete This Item !!!")) {
      let data = { 'id': this.carId };
      const url = "http://localhost:3000/deleteData";
      let result = await this.http.post(url, data).toPromise();
      console.log(result);
      alert("deleted successfully")
    } else {
      alert("You Cancelled Delete Action ")
    }
  }
}
