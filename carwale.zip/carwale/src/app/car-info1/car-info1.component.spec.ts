import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarInfo1Component } from './car-info1.component';

describe('CarInfo1Component', () => {
  let component: CarInfo1Component;
  let fixture: ComponentFixture<CarInfo1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarInfo1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarInfo1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
