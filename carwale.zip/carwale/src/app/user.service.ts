import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  isAdminObs: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  constructor() { }
  setisAdminObs(isAdmin) {
    this.isAdminObs.next(isAdmin);

  }

  getisAdminObs(): Observable<boolean> {
    return this.isAdminObs.asObservable();


  }
}
