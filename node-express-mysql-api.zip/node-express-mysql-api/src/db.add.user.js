const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
  host: "localhost",
  user: "root",
  password: "root",
  database: "carwale",
};

let addUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "INSERT INTO USER (USERNAME, PASSWORD, EMAIL, MOBILE) VALUES (?, ?, ?, ?);";
  await connection.queryAsync(sql, [
    input.username,
    input.password,
    input.email,
    input.mobile,
  ]);



  await connection.endAsync();
};

let authenticateUser = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM USER WHERE USERNAME=? AND PASSWORD=?;";
  const results = await connection.queryAsync(sql, [
    input.username,
    input.password,
  ]);

  await connection.endAsync();

  if (results.length === 0) {
    throw new Error("Invalid Credentials");
  }

  return results;
};

let getCarDetails = async () => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM car_details";
  const results = await connection.queryAsync(sql);

  await connection.endAsync();

  return results;
};

let getSpecCarDetails = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql = "SELECT * FROM car_details where carId=?";
  const results = await connection.queryAsync(sql, [input.id]);

  await connection.endAsync();

  return results;
};

let forgetPasswordValid = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "UPDATE USER SET PASSWORD=? WHERE EMAIL=?";
  await connection.queryAsync(sql, [
    input.password,
    input.email,

  ]);
}

let updateCarData = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "UPDATE CAR_Details SET company=?, price=?, carType=?, mileage=?, engine=?, fuelType=?, seatingCapacity=? where carId=?";
  await connection.queryAsync(sql, [
    input.company,
    input.price,
    input.carType,
    input.mileage,
    input.engine,
    input.fuelType,
    input.seatingCapacity,
    input.carId

  ]);
}
let deleteCarData = async (input) => {
  const connection = mysql.createConnection(DB_CONFIG);
  await connection.connectAsync();

  let sql =
    "delete FROM car_details where carId=?";
  await connection.queryAsync(sql, [input.id]);
  return results;
}


module.exports = { addUser, authenticateUser, getCarDetails, getSpecCarDetails, forgetPasswordValid, updateCarData, deleteCarData };
