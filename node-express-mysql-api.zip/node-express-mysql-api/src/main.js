const express = require("express");
const cors = require("cors");
const multer = require("multer");

const app = express();

// Middelware :: Programs :: Which runs in advance.
app.use(cors()); // unblocking cors policy
app.use(express.json()); // BODY :: RAW :: JSON
app.use(express.urlencoded({ extended: true })); // BODY :: URL ENCODED
const upload = multer(); // BODY :: FORM DATA

const dbadduser = require("./db.add.user");

// http://localhost:3000/welcome
app.get("/a", (req, res) => {
  res.json({ title: "Welcome!!" });
});

// created an API
// learnt how to read the input; coming from client.
// http://localhost:3000/adduser?username=hello
app.get("/adduser", async (req, res) => {
  try {
    // lets read the query parameter
    const input = req.query;

    // calling db logic :: async :: non blocking
    await dbadduser.addUser(input);
    res.json({ message: "success" });
  } catch (err) {
    res.json({ message: "failure" });
  }
});

// POST API :: FOR TESTIG POSTMAN :: ANDROID :: IOS :: BROWSER
// http://localhost:3000/adduser
app.post("/adduser", async (req, res) => {
  try {
    const input = req.body; // before doing this

    await dbadduser.addUser(input);
    res.json({ message: "success post" });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});

app.post("/auth-user", async (req, res) => {
  try {
    const input = req.body;

    let results = await dbadduser.authenticateUser(input);

    res.json({ opr: true, result: results });
  } catch (err) {
    res.json({ opr: false });
  }
});

app.post("/sample", upload.none(), async (req, res) => {
  res.json(req.body);
});

app.post("/get-car-details", async (req, res) => {
  try {
    let data = await dbadduser.getCarDetails();
    console.log(data);

    res.json({ message: "success post", result: data });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});

app.post("/getCarDetailsById", async (req, res) => {
  try {
    let input = req.body;
    let data = await dbadduser.getSpecCarDetails(input);
    var imageData = data[0].path;
    var imagePathArray = imageData.split(',');
    console.log(imagePathArray);
    data[0].imagePath = imagePathArray;
    console.log(data);
    res.json({ message: "success post", result: data });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});

app.get("/forgotPassword", async (req, res) => {
  try {

    const input = req.body;
    await dbadduser.forgetPasswordValid(input);
    res.json({ message: "success" });
  } catch (err) {
    res.json({ message: "failure" });
  }
});

app.post("/updateData", async (req, res) => {
  try {
    const input = req.body;
    let data = await dbadduser.updateCarData(input);
    console.log(data);

    res.json({ message: "success post", result: data });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});

app.post("/deleteData", async (req, res) => {
  try {
    const input = req.body;
    let data = await dbadduser.deleteCarData(input);
    console.log(data);
    res.json({ message: "success post", result: data });
  } catch (err) {
    res.json({ message: "failure post" });
  }
});


app.listen(3000);
